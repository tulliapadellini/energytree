#' Simulated data
#'
#' A dataset containing simulated data for Regression.
#'
"sim_reg"
